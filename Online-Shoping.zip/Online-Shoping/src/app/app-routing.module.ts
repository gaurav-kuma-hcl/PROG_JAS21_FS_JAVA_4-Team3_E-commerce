import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ArrivalComponent } from './arrival/arrival.component';
import { FeaturedComponent } from './featured/featured.component';
import { GalleryComponent } from './gallery/gallery.component';
import { DealComponent } from './deal/deal.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CartComponent } from './cart/cart.component';
import { AccountComponent } from './account/account.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'arrival', component:ArrivalComponent},
  { path: 'featured', component:FeaturedComponent},
  { path: 'gallery', component:GalleryComponent},
  { path: 'deal', component:DealComponent},
  { path: 'wishlist', component:WishlistComponent},
  { path: 'cart',component:CartComponent},
  { path: 'account', component:AccountComponent}
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
