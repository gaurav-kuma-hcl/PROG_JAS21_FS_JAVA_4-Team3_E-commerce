import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { HomeComponent } from './home/home.component';
import { AccountComponent } from './account/account.component';
import { ArrivalComponent } from './arrival/arrival.component';
import { FeaturedComponent } from './featured/featured.component';
import { GalleryComponent } from './gallery/gallery.component';
import { DealComponent } from './deal/deal.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CartComponent } from './cart/cart.component';
import { FooterComponent } from './footer/footer.component';
import { SignupComponent } from './account/signup/signup.component';


@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HomeComponent,
    AccountComponent,
    ArrivalComponent,
    FeaturedComponent,
    GalleryComponent,
    DealComponent,
    WishlistComponent,
    CartComponent,
    FooterComponent,
    SignupComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
