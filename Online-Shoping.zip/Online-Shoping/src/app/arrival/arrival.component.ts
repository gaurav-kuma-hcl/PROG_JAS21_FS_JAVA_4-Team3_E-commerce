import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arrival',
  templateUrl: './arrival.component.html',
  styleUrls: ['./arrival.component.css']
})
export class ArrivalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
