package demos.springdatajpa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import demos.springdatajpa.dao.UserDAO;
import demos.springdatajpa.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserDAO udao;
	

	public User add(User u) {
		return udao.save(u);
	}
	
	public User getById(int id) {
		User user=null;
		Optional<User> opt = udao.findById(id);
		if(opt.isPresent()) {
			user = opt.get();
		}
		return user;
	}
	
	public List<User> getAll() {
		List<User> users = new ArrayList<User>();
		Iterable<User> it = udao.findAll();
		it.forEach(user -> {
			users.add(user);
		});
		return users;
	}
	
	public User update(User u) {
		return udao.save(u);
	}
	
	public void delete(int userid) {
		udao.deleteById(userid);
	}
	
	

}
