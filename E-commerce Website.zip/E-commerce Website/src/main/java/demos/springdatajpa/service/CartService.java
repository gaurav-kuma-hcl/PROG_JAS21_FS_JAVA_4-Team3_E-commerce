package demos.springdatajpa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import demos.springdatajpa.dao.CartDAO;
import demos.springdatajpa.model.Cart;

@Service
public class CartService {
	
	@Autowired
	private CartDAO cdao;
	

	public Cart add(Cart c) {
		return cdao.save(c);
	}
	
	public Cart getById(int id) {
		Cart cart=null;
		Optional<Cart> opt = cdao.findById(id);
		if(opt.isPresent()) {
			cart = opt.get();
		}
		return cart;
	}
	
	public List<Cart> getAll() {
		List<Cart> carts = new ArrayList<Cart>();
		Iterable<Cart> it = cdao.findAll();
		it.forEach(cart -> {
			carts.add(cart);
		});
		return carts;
	}
	
	public Cart update(Cart c) {
		return cdao.save(c);
	}
	
	public void delete(int productid) {
		cdao.deleteById(productid);
	}
	
	

}