package demos.springdatajpa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import demos.springdatajpa.dao.CategoryDAO;
import demos.springdatajpa.model.Category;
import demos.springdatajpa.model.Product;

@Service
public class CategoryService {
	
	@Autowired
	private CategoryDAO dao;
	
	public Category add(Category c) {
		return dao.save(c);
	}
	
	public Category getById(int id) {
		Category category = null;
		Optional<Category> opt = dao.findById(id);
		if(opt.isPresent()) {
			category = opt.get();
		}
		return category;
	}
	
	public List<Category> getAll() {
		List<Category> categories = new ArrayList<Category>();
		Iterable<Category> it = dao.findAll();
		it.forEach(category -> {
			categories.add(category);
		});
		return categories;
	}
	
	public Category update(Category c) {
		return dao.save(c);
	}
	
	public void delete(int categoryId) {
		dao.deleteById(categoryId);
	}

}
