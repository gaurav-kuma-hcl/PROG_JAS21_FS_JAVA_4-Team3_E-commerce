package demos.springdatajpa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import demos.springdatajpa.dao.ProductDAO;
import demos.springdatajpa.model.Product;

@Service
public class ProductService {
	
	@Autowired
	private ProductDAO dao;
	

	public Product add(Product p) {
		return dao.save(p);
	}
	
	public Product getById(int id) {
		Product product = null;
		Optional<Product> opt = dao.findById(id);
		if(opt.isPresent()) {
			product = opt.get();
		}
		return product;
	}
	
	public List<Product> getByCategory(int catId) {
		return dao.findByCategoryId(catId);
	}
	
	public List<Product> getAll() {
		List<Product> products = new ArrayList<Product>();
		Iterable<Product> it = dao.findAll();
		it.forEach(product -> {
			products.add(product);
		});
		return products;
	}
	
	public Product update(Product p) {
		return dao.save(p);
	}
	
	public void delete(int productId) {
		dao.deleteById(productId);
	}
	
	

}
