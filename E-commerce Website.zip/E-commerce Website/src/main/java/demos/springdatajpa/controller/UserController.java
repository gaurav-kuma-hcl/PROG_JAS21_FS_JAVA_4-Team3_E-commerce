package demos.springdatajpa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import demos.springdatajpa.model.User;
import demos.springdatajpa.service.UserService;

@RestController
@CrossOrigin
public class UserController {
	
	@Autowired
	private UserService service;
	
	@PostMapping("/user")
	public User add(@RequestBody User u) {
		return service.add(u);
	}
	
	@GetMapping("/user/{id}")
	public User getById(@PathVariable("id")int id) {
		return service.getById(id);
	}
	
	@GetMapping("/users")
	public List<User> getAll() {
		return service.getAll();
	}
	
	@PutMapping("/users/{id}")
	public User update(@PathVariable("id") int id, @RequestBody User u) {
		u.setUserid(id);
		return service.update(u);
	}
	
	@DeleteMapping("/users/{id}")
	public void delete(@PathVariable("id") int userId) {
		service.delete(userId);
	}

}
