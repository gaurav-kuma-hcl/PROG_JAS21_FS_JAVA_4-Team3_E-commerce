package demos.springdatajpa.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import demos.springdatajpa.model.Category;
import demos.springdatajpa.model.Product;
import demos.springdatajpa.service.ProductService;

@RestController
@CrossOrigin
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	//@PostMapping("/products")
	@PostMapping("/categories/{id}/products")
	public Product add(@PathVariable("id")int catId,@RequestBody Product p) {
		p.setCategory(new Category(catId, "", ""));
		return service.add(p);
	}
	
	
	
	@GetMapping("/products/{id}")
	public Product getById(@PathVariable("id")int id) {
		return service.getById(id);
	}
	
	@GetMapping("/products")
	public List<Product> getAll() {
		return service.getAll();
	}
	
	@GetMapping("/categories/{id}/products")
	public List<Product> getByCategory(@PathVariable("id") int catId) {
		return service.getByCategory(catId);
	}
	
	@PutMapping("/products/{id}")
	public Product update(@PathVariable("id") int id, @RequestBody Product p) {
		p.setId(id);
		return service.update(p);
	}
	
	@DeleteMapping("/products/{id}")
	public void delete(@PathVariable("id") int productId) {
		service.delete(productId);
	}

}
