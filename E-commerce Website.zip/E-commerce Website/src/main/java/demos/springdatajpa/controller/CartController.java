package demos.springdatajpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import demos.springdatajpa.model.Cart;
import demos.springdatajpa.service.CartService;


@RestController
@CrossOrigin
public class CartController {
	
	@Autowired
	private CartService service;
	
	@PostMapping("/cart")
	public Cart add(@RequestBody Cart c) {
		return service.add(c);
	}
	
	@GetMapping("/cart/{id}")
	public Cart getById(@PathVariable("id")int id) {
		return service.getById(id);
	}
	
	@GetMapping("/carts")
	public List<Cart> getAll() {
		return service.getAll();
	}
	
	@PutMapping("/carts/{id}")
	public Cart update(@PathVariable("id") int productid, @RequestBody Cart c) {
		c.setId(productid);
		return service.update(c);
	}
	
	@DeleteMapping("/carts/{id}")
	public void delete(@PathVariable("id") int productId) {
		service.delete(productId);
	}

}
