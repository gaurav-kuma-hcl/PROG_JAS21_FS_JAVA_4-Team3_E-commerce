package demos.springdatajpa.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import demos.springdatajpa.model.Category;

@Repository
public interface CategoryDAO extends CrudRepository<Category, Integer> {

}
