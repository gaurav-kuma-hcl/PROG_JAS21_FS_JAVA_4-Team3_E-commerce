package demos.springdatajpa.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import demos.springdatajpa.model.Cart;

@Repository
public interface CartDAO extends CrudRepository<Cart, Integer> {
	
	

	
}