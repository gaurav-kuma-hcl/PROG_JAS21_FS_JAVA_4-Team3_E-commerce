package demos.springdatajpa.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import demos.springdatajpa.model.Product;

@Repository
public interface ProductDAO extends CrudRepository<Product, Integer> {

	Product findByName(String name);
	
	List<Product> findByBrand(String brandName);
	
	List<Product> findByPrice(double price);
	
	List<Product> findByCategoryId(int catId);
}
